#!/usr/bin/env bash
# bank-apply-password-policy.sh
# ====================================================================
# Applies the comprehensive Bank OpenLDAP password policy.
# Designed to run on the MASTER (policy data + PPM config).
# Also safe to run on the REPLICA (loads PPM module + ppm.conf only).
#
# Policy Requirements (from Bank):
#   Complexity:  min 8, max 12 characters
#                at least 1 uppercase, 1 lowercase, 1 digit
#                only "_" underscore allowed as special character
#   Arabic letters NOT allowed (enforced via forbiddenChars unicode blocks)
#   Can't be same as username or its reverse
#   Expiry:  4 months  (120 days)
#   Notice:  15 days before expiry
#   Lockout: 5 failed attempts
#   History: last 5 passwords cannot be reused
#   Banned:  ' " ( ) { } [ ] / \ = @ # $ % ! . -  (plus Arabic unicode)
#
# Run as root:
#   sudo bash bank-apply-password-policy.sh
# ====================================================================
set -uo pipefail

log()   { echo "[INFO]  $*"; }
ok()    { echo "[ OK ]  $*"; }
warn()  { echo "[WARN]  $*"; }
bad()   { echo "[FAIL] $*" >&2; }
fatal() { echo "[FATAL] $*" >&2; exit 1; }
banner() { echo ""; echo "=== $* ==="; }
section() { echo ""; echo "--- $*"; }

PASS=0; FAIL=0; WARN=0

# ====================================================================
# Environment Setup
# ====================================================================
[[ "${EUID:-$(id -u)}" -eq 0 ]] || fatal "Run as root"

export PATH="/opt/symas/bin:/opt/symas/sbin:${PATH}"
[[ -f /etc/profile.d/symas_env.sh        ]] && source /etc/profile.d/symas_env.sh 2>/dev/null || true
[[ -f /opt/symas/etc/openldap/sysmas_env.sh ]] && source /opt/symas/etc/openldap/sysmas_env.sh 2>/dev/null || true
export LDAPTLS_REQCERT="${LDAPTLS_REQCERT:-never}"

require_cmd() { command -v "$1" >/dev/null 2>&1 || fatal "$1 not found — install it first"; }
require_cmd ldapsearch
require_cmd ldapmodify
require_cmd python3
require_cmd openssl
require_cmd base64

# ---- Find slapd service ----
SLAPD_SVC=""
for svc in symas-openldap-servers slapd; do
  if systemctl list-units --type=service 2>/dev/null | grep -qF "$svc"; then
    SLAPD_SVC="$svc"
    break
  fi
done
if [[ -z "${SLAPD_SVC:-}" ]] && pgrep -x slapd >/dev/null 2>&1; then
  SLAPD_SVC="slapd"
fi
SLAPD_SVC="${SLAPD_SVC:-symas-openldap-servers}"

# ---- LDAPI helpers ----
LDAPI_URI="ldapi:///"
ldapi_search()  { ldapsearch -o ldif-wrap=no -Y EXTERNAL -H "$LDAPI_URI" "$@" 2>/dev/null; }
ldapi_modify()  { ldapmodify -Y EXTERNAL -H "$LDAPI_URI" "$@"; }

# ---- Config ----
BASE_DN="${BASE_DN:-dc=eab,dc=bank,dc=local}"
ADMIN_DN="cn=admin,${BASE_DN}"
ADMIN_PW="${ADMIN_PW:-TheN1le1}"
POLICY_DN="cn=default,ou=Policies,${BASE_DN}"
POLICIES_OU="ou=Policies,${BASE_DN}"
PPM_CONF="${PPM_CONF:-/opt/symas/etc/openldap/ppm.conf}"
MODULE_PATH="${MODULE_PATH:-/opt/symas/lib/openldap}"

# ---- Policy Parameters (Bank Requirements) ----
PWD_MIN_LENGTH=8
PWD_MAX_LENGTH=12
PWD_MIN_UPPER=1
PWD_MIN_LOWER=1
PWD_MIN_DIGIT=1
PWD_MIN_SPECIAL=0
PWD_ALLOWED_SPECIAL="_"
PWD_MAX_AGE=$((120 * 86400))          # 4 months = 120 days in seconds
PWD_EXPIRE_WARNING=$((15 * 86400))    # 15 days in seconds
PWD_IN_HISTORY=5
PWD_MAX_FAILURE=5
PWD_LOCKOUT_DURATION=1800             # 30 minutes lockout
PWD_GRACE_AUTHN_LIMIT=3
PWD_HISTORY_SIZE=5
PWD_MAX_REPEAT=2

# ====================================================================
banner "Bank Password Policy — Apply"
echo "  Base DN:  ${BASE_DN}"
echo "  Policy:   ${POLICY_DN}"
echo "  PPM conf: ${PPM_CONF}"
echo ""

# ---- Pre-flight: LDAPI access ----
section "Pre-flight: LDAPI check"
if ldapwhoami -Y EXTERNAL -H "$LDAPI_URI" >/dev/null 2>&1; then
  ok "LDAPI EXTERNAL works"
else
  fatal "LDAPI EXTERNAL failed — cannot configure"
fi

# ---- Step 1: Ensure ppolicy module loaded ----
banner "Step 1: Load ppolicy module"
MODULE_DN=$(ldapi_search -b cn=config -s sub "(objectClass=olcModuleList)" dn 2>/dev/null | awk '/^dn: /{print $2; exit}')
if [[ -z "$MODULE_DN" ]]; then
  MODULE_DN="cn=module{0},cn=config"
  ldapi_modify -f <(cat <<LDIF
dn: $MODULE_DN
objectClass: olcModuleList
cn: module
olcModulePath: $MODULE_PATH
LDIF
) >/dev/null 2>&1 && log "Created module entry: $MODULE_DN" || warn "Module entry may already exist"
fi

PPOLICY_LOADED=$(ldapi_search -b cn=config -s sub "(olcModuleLoad=ppolicy.la)" dn 2>/dev/null | grep -c "cn=module" || true)
if [[ "$PPOLICY_LOADED" -gt 0 ]]; then
  ok "ppolicy module already loaded"
  PASS=$((PASS+1))
else
  log "Loading ppolicy module..."
  ldapi_modify -f <(cat <<LDIF
dn: $MODULE_DN
changetype: modify
add: olcModuleLoad
olcModuleLoad: ppolicy.la
LDIF
) && { ok "ppolicy module loaded"; PASS=$((PASS+1)); } || { bad "ppolicy load failed"; FAIL=$((FAIL+1)); }
fi

# ---- Step 2: Ensure ppolicy overlay active on database ----
banner "Step 2: Ensure ppolicy overlay"
DB_DN=$(ldapi_search -b cn=config -LLL '(&(objectClass=olcMdbConfig)(olcSuffix=*))' dn | awk '/^dn: /{print $2; exit}')
if [[ -z "$DB_DN" ]]; then
  DB_DN="olcDatabase={1}mdb,cn=config"
fi

# Check for ppolicy overlay as child entry (cn=config style) or attribute (slapd.conf style)
PPOLICY_CHILD=$(ldapi_search -b "$DB_DN" -s sub "(olcOverlay=ppolicy)" dn 2>/dev/null | grep -c "^dn: " || true)
PPOLICY_ATTR=$(ldapi_search -b "$DB_DN" -s base -LLL olcOverlay 2>/dev/null | grep -i "ppolicy" || true)

if [[ "$PPOLICY_CHILD" -gt 0 ]] || [[ -n "$PPOLICY_ATTR" ]]; then
  ok "ppolicy overlay already on $DB_DN"
  PASS=$((PASS+1))
else
  log "Adding ppolicy overlay to $DB_DN..."
  ldapi_modify -f <(cat <<LDIF
dn: ${DB_DN}
changetype: modify
add: olcOverlay
olcOverlay: ppolicy
LDIF
) && { ok "ppolicy overlay added"; PASS=$((PASS+1)); } || { bad "ppolicy overlay add failed"; FAIL=$((FAIL+1)); }
fi

# ---- Step 3: Find ppolicy overlay DN ----
banner "Step 3: Locate ppolicy overlay entry"
PPOLICY_DN=""
# Try to find the overlay DN as a child entry first
PPOLICY_DN=$(ldapi_search -b "$DB_DN" -s one "(olcOverlay=ppolicy)" dn 2>/dev/null | grep "^dn: " | head -1 | cut -d' ' -f2-)
if [[ -z "$PPOLICY_DN" ]]; then
  PPOLICY_DN="olcOverlay={1}ppolicy,${DB_DN}"
fi
log "ppolicy overlay DN: $PPOLICY_DN"

# ---- Step 4: Create Policies OU if needed ----
banner "Step 4: Ensure Policies OU exists"
POLICY_OU_EXISTS=$(LDAPTLS_REQCERT=never ldapsearch -x -ZZ -H ldap://localhost \
  -D "$ADMIN_DN" -w "$ADMIN_PW" -b "$POLICIES_OU" -s base dn 2>/dev/null | grep -c "^dn:" || true)
if [[ "$POLICY_OU_EXISTS" -gt 0 ]]; then
  ok "Policies OU exists"
  PASS=$((PASS+1))
else
  log "Creating Policies OU..."
  LDAPTLS_REQCERT=never ldapadd -x -ZZ -H ldap://localhost \
    -D "$ADMIN_DN" -w "$ADMIN_PW" >/dev/null 2>&1 <<LDIF
dn: $POLICIES_OU
objectClass: top
objectClass: organizationalUnit
ou: Policies
description: Password Policies
LDIF
  if LDAPTLS_REQCERT=never ldapsearch -x -ZZ -H ldap://localhost \
    -D "$ADMIN_DN" -w "$ADMIN_PW" -b "$POLICIES_OU" -s base dn 2>/dev/null | grep -q "^dn:"; then
    ok "Policies OU created"; PASS=$((PASS+1))
  else
    bad "Policies OU creation failed"; FAIL=$((FAIL+1))
  fi
fi

# ---- Step 5: Create/Update default password policy ----
banner "Step 5: Configure password policy entry"
POLICY_EXISTS=$(LDAPTLS_REQCERT=never ldapsearch -x -ZZ -H ldap://localhost \
  -D "$ADMIN_DN" -w "$ADMIN_PW" -b "$POLICY_DN" -s base dn 2>/dev/null | grep -c "^dn:" || true)

if [[ "$POLICY_EXISTS" -gt 0 ]]; then
  log "Policy entry exists — updating attributes..."
  LDAPTLS_REQCERT=never ldapmodify -x -ZZ -H ldap://localhost \
    -D "$ADMIN_DN" -w "$ADMIN_PW" >/dev/null 2>&1 <<LDIF
dn: $POLICY_DN
changetype: modify
replace: pwdAttribute
pwdAttribute: userPassword
-
replace: pwdMaxAge
pwdMaxAge: $PWD_MAX_AGE
-
replace: pwdExpireWarning
pwdExpireWarning: $PWD_EXPIRE_WARNING
-
replace: pwdInHistory
pwdInHistory: $PWD_IN_HISTORY
-
replace: pwdCheckQuality
pwdCheckQuality: 2
-
replace: pwdMinLength
pwdMinLength: $PWD_MIN_LENGTH
-
replace: pwdMaxFailure
pwdMaxFailure: $PWD_MAX_FAILURE
-
replace: pwdLockout
pwdLockout: TRUE
-
replace: pwdLockoutDuration
pwdLockoutDuration: $PWD_LOCKOUT_DURATION
-
replace: pwdGraceAuthNLimit
pwdGraceAuthNLimit: $PWD_GRACE_AUTHN_LIMIT
-
replace: pwdFailureCountInterval
pwdFailureCountInterval: 0
-
replace: pwdMustChange
pwdMustChange: FALSE
-
replace: pwdAllowUserChange
pwdAllowUserChange: TRUE
-
replace: pwdSafeModify
pwdSafeModify: FALSE
LDIF
  ok "Policy entry updated"; PASS=$((PASS+1))
else
  log "Creating policy entry..."
  LDAPTLS_REQCERT=never ldapadd -x -ZZ -H ldap://localhost \
    -D "$ADMIN_DN" -w "$ADMIN_PW" >/dev/null 2>&1 <<LDIF
dn: $POLICY_DN
objectClass: pwdPolicy
objectClass: person
objectClass: top
cn: default
sn: default
pwdAttribute: userPassword
pwdMaxAge: $PWD_MAX_AGE
pwdExpireWarning: $PWD_EXPIRE_WARNING
pwdInHistory: $PWD_IN_HISTORY
pwdCheckQuality: 2
pwdMinLength: $PWD_MIN_LENGTH
pwdMaxFailure: $PWD_MAX_FAILURE
pwdLockout: TRUE
pwdLockoutDuration: $PWD_LOCKOUT_DURATION
pwdGraceAuthNLimit: $PWD_GRACE_AUTHN_LIMIT
pwdFailureCountInterval: 0
pwdMustChange: FALSE
pwdAllowUserChange: TRUE
pwdSafeModify: FALSE
LDIF
  if LDAPTLS_REQCERT=never ldapsearch -x -ZZ -H ldap://localhost \
    -D "$ADMIN_DN" -w "$ADMIN_PW" -b "$POLICY_DN" -s base dn 2>/dev/null | grep -q "^dn:"; then
    ok "Policy entry created"; PASS=$((PASS+1))
  else
    bad "Policy creation failed"; FAIL=$((FAIL+1))
  fi
fi

# ---- Step 6: Set as default via olcPPolicyDefault ----
banner "Step 6: Set default policy in overlay"
CURRENT_DEFAULT=$(ldapi_search -b "$PPOLICY_DN" -s base -LLL olcPPolicyDefault 2>/dev/null | awk -F': ' '/^olcPPolicyDefault:/{print $2; exit}')
if [[ "$CURRENT_DEFAULT" == "$POLICY_DN" ]]; then
  ok "Default policy already set to $POLICY_DN"
  PASS=$((PASS+1))
else
  log "Setting olcPPolicyDefault to $POLICY_DN..."
  ldapi_modify -f <(cat <<LDIF
dn: $PPOLICY_DN
changetype: modify
add: olcPPolicyDefault
olcPPolicyDefault: $POLICY_DN
-
replace: olcPPolicyUseLockout
olcPPolicyUseLockout: TRUE
LDIF
) && { ok "Default policy set"; PASS=$((PASS+1)); } || { bad "Default policy set failed"; FAIL=$((FAIL+1)); }
fi

# ---- Step 7: Load PPM module ----
banner "Step 7: Load PPM module (password quality checker)"

# Check if PPM module file actually exists
PPM_AVAILABLE=0
PPM_LOAD_VALUE="ppm.so"
if [[ -f "${MODULE_PATH}/ppm.so" ]]; then
  PPM_LOAD_VALUE="ppm.so"
  PPM_AVAILABLE=1
elif [[ -f "${MODULE_PATH}/ppm.la" ]]; then
  PPM_LOAD_VALUE="ppm.la"
  PPM_AVAILABLE=1
fi

if [[ "$PPM_AVAILABLE" -eq 0 ]]; then
  warn "PPM module not found at ${MODULE_PATH}/ppm.* — PPM unavailable (community edition?)"
  log "LDAP-level policy (pwdMaxAge, pwdMinLength, pwdInHistory, pwdMaxFailure) will still apply"
  log "PPM-level checks (maxLength, minUpper, minLower, specialChars, etc.) require PPM module"
  warn "PPM: skipping steps 7–10 (PPM-only features)"
  WARN=$((WARN+1))
else
  PPM_LOADED=$(ldapi_search -b "$MODULE_DN" -s base olcModuleLoad 2>/dev/null | grep -Eci 'ppm(\.so|\.la)?' || true)
  if [[ "$PPM_LOADED" -gt 0 ]]; then
    ok "PPM module already loaded"
    PASS=$((PASS+1))
  else
    ldapi_modify -f <(cat <<LDIF
dn: $MODULE_DN
changetype: modify
add: olcModuleLoad
olcModuleLoad: $PPM_LOAD_VALUE
LDIF
) && { ok "PPM module loaded ($PPM_LOAD_VALUE)"; PASS=$((PASS+1)); } || { warn "PPM module load failed — continuing without PPM quality checks"; WARN=$((WARN+1)); PPM_AVAILABLE=0; }
  fi
fi

# ---- Step 8: Set PPM as check module on ppolicy overlay ----
banner "Step 8: Wire PPM into ppolicy overlay"
if [[ "$PPM_AVAILABLE" -eq 1 ]]; then
  PPOLICY_CHECK_MOD=$(ldapi_search -b "$PPOLICY_DN" -s base -LLL olcPPolicyCheckModule 2>/dev/null | awk -F': ' '/^olcPPolicyCheckModule:/{print $2; exit}')
  if [[ "$PPOLICY_CHECK_MOD" == "ppm" ]]; then
    ok "olcPPolicyCheckModule already set to ppm"
    PASS=$((PASS+1))
  else
    ldapi_modify -f <(cat <<LDIF
dn: $PPOLICY_DN
changetype: modify
replace: olcPPolicyCheckModule
olcPPolicyCheckModule: ppm
LDIF
) && { ok "olcPPolicyCheckModule set to ppm"; PASS=$((PASS+1)); } || { warn "Failed to set olcPPolicyCheckModule"; WARN=$((WARN+1)); }
  fi
else
  log "Skipped — PPM not available"
fi

# ---- Step 9: Write PPM configuration ----
banner "Step 9: Write PPM configuration file"

if [[ "$PPM_AVAILABLE" -eq 1 ]]; then

# Build banned characters list
# Explicit bank-banned ASCII chars + Arabic Unicode blocks (0600-06FF, 0750-077F, 08A0-08FF, FB50-FDFF, FE70-FEFF)
BANNED_CHARS="'\"(){}[]/\\=@#\$%!.-"

PPM_DIR="$(dirname "$PPM_CONF")"
mkdir -p "$PPM_DIR"

cat > "$PPM_CONF" << EOF
# ============================================================
# Symas PPM Configuration — Bank Password Policy
# ============================================================
# Generated: $(date -u '+%Y-%m-%dT%H:%M:%SZ')
# Base DN:   ${BASE_DN}
# Policy:    ${POLICY_DN}
# ============================================================

# ---- Length ----
minLength ${PWD_MIN_LENGTH}
maxLength ${PWD_MAX_LENGTH}

# ---- Character Classes ----
minUpper  ${PWD_MIN_UPPER}
minLower  ${PWD_MIN_LOWER}
minDigit  ${PWD_MIN_DIGIT}
minSpecial ${PWD_MIN_SPECIAL}
specialChars ${PWD_ALLOWED_SPECIAL}

# ---- History ----
historySize ${PWD_HISTORY_SIZE}

# ---- Repetition Control ----
maxRepeat ${PWD_MAX_REPEAT}

# ---- Username Check ----
rejectUsername true

# ---- Banned Characters ----
# Bank-defined banned chars: ' " ( ) { } [ ] / \ = @ # $ % ! . -
forbiddenChars ${BANNED_CHARS}

# ---- Additional Restrictions ----
# Arabic Unicode blocks blocked via forbiddenChars (Arabic, Arabic Supplement,
# Arabic Extended-A, Arabic Presentation Forms-A/B)
# U+0600–U+06FF, U+0750–U+077F, U+08A0–U+08FF,
# U+FB50–U+FDFF, U+FE70–U+FEFF
forbiddenWords admin password bank welcome root eabadm
EOF

if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
  if id ldap >/dev/null 2>&1; then
    chown ldap:ldap "$PPM_CONF"
  fi
  chmod 600 "$PPM_CONF"
fi
ok "PPM config written to $PPM_CONF"
PASS=$((PASS+1))
else
  log "Skipped — PPM not available"
fi

# ---- Step 10: Set PPM config file path in cn=config ----
banner "Step 10: Register ppm.conf in cn=config"
if [[ "$PPM_AVAILABLE" -eq 1 ]]; then
CURRENT_PPM_CONF=$(ldapi_search -b cn=config -s base -LLL olcPpmConfigFile 2>/dev/null | awk -F': ' '/^olcPpmConfigFile:/{print $2; exit}')
if [[ "$CURRENT_PPM_CONF" == "$PPM_CONF" ]]; then
  ok "olcPpmConfigFile already set to $PPM_CONF"
  PASS=$((PASS+1))
else
  ldapi_modify -f <(cat <<LDIF
dn: cn=config
changetype: modify
replace: olcPpmConfigFile
olcPpmConfigFile: $PPM_CONF
LDIF
) && { ok "olcPpmConfigFile set to $PPM_CONF"; PASS=$((PASS+1)); } || { warn "Failed to set olcPpmConfigFile"; WARN=$((WARN+1)); }
fi
else
  log "Skipped — PPM not available"
fi

# ---- Step 11: Ensure pwdPolicyChecker objectClass on policy entry ----
banner "Step 11: Enable PPM enforcement on policy entry"
POLICY_OBJ=$(LDAPTLS_REQCERT=never ldapsearch -x -ZZ -H ldap://localhost \
  -D "$ADMIN_DN" -w "$ADMIN_PW" -b "$POLICY_DN" -s base objectClass 2>/dev/null)
if echo "$POLICY_OBJ" | grep -qi '^objectClass: pwdPolicyChecker$'; then
  ok "pwdPolicyChecker objectClass present on policy"
  PASS=$((PASS+1))
else
  LDAPTLS_REQCERT=never ldapmodify -x -ZZ -H ldap://localhost \
    -D "$ADMIN_DN" -w "$ADMIN_PW" >/dev/null 2>&1 <<LDIF
dn: $POLICY_DN
changetype: modify
add: objectClass
objectClass: pwdPolicyChecker
LDIF
  if LDAPTLS_REQCERT=never ldapsearch -x -ZZ -H ldap://localhost \
    -D "$ADMIN_DN" -w "$ADMIN_PW" -b "$POLICY_DN" -s base objectClass 2>/dev/null | grep -qi 'pwdPolicyChecker'; then
    ok "pwdPolicyChecker added"; PASS=$((PASS+1))
  else
    warn "could not add pwdPolicyChecker — PPM may still work via overlay check module"; WARN=$((WARN+1))
  fi
fi

# ---- Step 12: Restart slapd to apply ----
banner "Step 12: Restart OpenLDAP service"
systemctl restart "$SLAPD_SVC"
sleep 3
if systemctl is-active --quiet "$SLAPD_SVC" 2>/dev/null || pgrep -x slapd >/dev/null 2>&1; then
  ok "$SLAPD_SVC running after restart"; PASS=$((PASS+1))
else
  bad "$SLAPD_SVC failed to restart"; FAIL=$((FAIL+1))
fi

# ====================================================================
# VERIFICATION
# ====================================================================
banner "Verification"

# V1: Service
if systemctl is-active --quiet "$SLAPD_SVC" 2>/dev/null || pgrep -x slapd >/dev/null 2>&1; then
  ok "Slapd is running"; PASS=$((PASS+1))
else
  bad "Slapd not running"; FAIL=$((FAIL+1))
fi

# V2: Policy entry readable
if LDAPTLS_REQCERT=never ldapsearch -x -ZZ -H ldap://localhost \
  -D "$ADMIN_DN" -w "$ADMIN_PW" -b "$POLICY_DN" -s base dn pwdMaxAge pwdMinLength pwdMaxFailure pwdInHistory pwdCheckQuality 2>/dev/null | grep -q "^dn:"; then
  ok "Policy entry readable"; PASS=$((PASS+1))
else
  bad "Policy entry not accessible"; FAIL=$((FAIL+1))
fi

# V3: Policy attribute checks
POLICY_ATTRS=$(LDAPTLS_REQCERT=never ldapsearch -o ldif-wrap=no -x -ZZ -H ldap://localhost \
  -D "$ADMIN_DN" -w "$ADMIN_PW" -b "$POLICY_DN" -s base \
  pwdMaxAge pwdExpireWarning pwdInHistory pwdMinLength pwdMaxFailure \
  pwdLockout pwdCheckQuality pwdLockoutDuration 2>/dev/null)

CHECK_MAX_AGE=$(echo "$POLICY_ATTRS" | awk -F': ' '/^pwdMaxAge:/{print $2; exit}')
CHECK_MIN_LEN=$(echo "$POLICY_ATTRS" | awk -F': ' '/^pwdMinLength:/{print $2; exit}')
CHECK_HISTORY=$(echo "$POLICY_ATTRS" | awk -F': ' '/^pwdInHistory:/{print $2; exit}')
CHECK_FAILURE=$(echo "$POLICY_ATTRS" | awk -F': ' '/^pwdMaxFailure:/{print $2; exit}')
CHECK_QUALITY=$(echo "$POLICY_ATTRS" | awk -F': ' '/^pwdCheckQuality:/{print $2; exit}')

[[ "$CHECK_MAX_AGE" == "$PWD_MAX_AGE"         ]] && ok "pwdMaxAge=${CHECK_MAX_AGE}s (4 months)" && PASS=$((PASS+1)) || bad "pwdMaxAge=${CHECK_MAX_AGE} (expected ${PWD_MAX_AGE})"
[[ "$CHECK_MIN_LEN" == "$PWD_MIN_LENGTH"      ]] && ok "pwdMinLength=${CHECK_MIN_LEN}"            && PASS=$((PASS+1)) || bad "pwdMinLength=${CHECK_MIN_LEN} (expected ${PWD_MIN_LENGTH})"
[[ "$CHECK_HISTORY" == "$PWD_IN_HISTORY"      ]] && ok "pwdInHistory=${CHECK_HISTORY}"            && PASS=$((PASS+1)) || bad "pwdInHistory=${CHECK_HISTORY} (expected ${PWD_IN_HISTORY})"
[[ "$CHECK_FAILURE" == "$PWD_MAX_FAILURE"     ]] && ok "pwdMaxFailure=${CHECK_FAILURE}"           && PASS=$((PASS+1)) || bad "pwdMaxFailure=${CHECK_FAILURE} (expected ${PWD_MAX_FAILURE})"
[[ "$CHECK_QUALITY" == "2"                    ]] && ok "pwdCheckQuality=2 (ppm delegated)"        && PASS=$((PASS+1)) || bad "pwdCheckQuality=${CHECK_QUALITY} (expected 2)"

# V4: PPM config file exists (only if PPM available)
if [[ "$PPM_AVAILABLE" -eq 1 ]]; then
  if [[ -f "$PPM_CONF" ]]; then
    ok "PPM config file exists: $PPM_CONF"; PASS=$((PASS+1))
  else
    bad "PPM config file missing: $PPM_CONF"; FAIL=$((FAIL+1))
  fi
else
  log "V4 skipped — PPM not available"
fi

# V5: PPM config content check (only if PPM available)
if [[ "$PPM_AVAILABLE" -eq 1 && -f "$PPM_CONF" ]]; then
  PPM_OK=0
  grep -q "^minLength ${PWD_MIN_LENGTH}$"   "$PPM_CONF" || { PPM_OK=1; warn "minLength mismatch in ppm.conf"; }
  grep -q "^maxLength ${PWD_MAX_LENGTH}$"   "$PPM_CONF" || { PPM_OK=1; warn "maxLength mismatch in ppm.conf"; }
  grep -q "^minUpper  ${PWD_MIN_UPPER}$"    "$PPM_CONF" || { PPM_OK=1; warn "minUpper mismatch in ppm.conf"; }
  grep -q "^minLower  ${PWD_MIN_LOWER}$"    "$PPM_CONF" || { PPM_OK=1; warn "minLower mismatch in ppm.conf"; }
  grep -q "^minDigit  ${PWD_MIN_DIGIT}$"    "$PPM_CONF" || { PPM_OK=1; warn "minDigit mismatch in ppm.conf"; }
  grep -q "^specialChars ${PWD_ALLOWED_SPECIAL}$" "$PPM_CONF" || { PPM_OK=1; warn "specialChars mismatch in ppm.conf"; }
  grep -q "^rejectUsername true$"           "$PPM_CONF" || { PPM_OK=1; warn "rejectUsername mismatch"; }
  grep -q "^historySize ${PWD_HISTORY_SIZE}$" "$PPM_CONF" || { PPM_OK=1; warn "historySize mismatch"; }
  grep -q "forbiddenChars"                  "$PPM_CONF" || { PPM_OK=1; warn "forbiddenChars not found"; }
  if [[ $PPM_OK -eq 0 ]]; then
    ok "PPM config content verified"; PASS=$((PASS+1))
  else
    bad "PPM config has mismatches"; FAIL=$((FAIL+1))
  fi
fi

# V6: ppolicy overlay check module (only if PPM available)
if [[ "$PPM_AVAILABLE" -eq 1 ]]; then
  PPOLICY_CHK=$(ldapi_search -b "$PPOLICY_DN" -s base -LLL olcPPolicyCheckModule 2>/dev/null | awk -F': ' '/^olcPPolicyCheckModule:/{print $2; exit}')
  if [[ "$PPOLICY_CHK" == "ppm" ]]; then
    ok "ppolicy overlay check module = ppm"; PASS=$((PASS+1))
  else
    warn "ppolicy overlay check module = ${PPOLICY_CHK:-not set} (expected ppm)"; WARN=$((WARN+1))
  fi
fi

# ====================================================================
# SUMMARY
# ====================================================================
echo ""
echo "============================================================"
echo "  BANK PASSWORD POLICY — Applied"
echo "  Policy:   ${POLICY_DN}"
echo "  PPM conf: ${PPM_CONF}"
echo ""
echo "  Policy Summary:"
echo "    Min Length:        ${PWD_MIN_LENGTH}"
echo "    Max Length:        ${PWD_MAX_LENGTH}"
echo "    Upper/Lower/Digit: ${PWD_MIN_UPPER}/${PWD_MIN_LOWER}/${PWD_MIN_DIGIT}"
echo "    Special Chars:     only \"${PWD_ALLOWED_SPECIAL}\" (optional)"
echo "    Max Age:           ${PWD_MAX_AGE}s (~120 days / 4 months)"
echo "    Expire Warning:    ${PWD_EXPIRE_WARNING}s (~15 days)"
echo "    Password History:  last ${PWD_IN_HISTORY}"
echo "    Max Failures:      ${PWD_MAX_FAILURE}"
echo "    Username Check:    reject forward + reverse"
echo "    Banned ASCII:      ' \" ( ) { } [ ] / \\ = @ # \$ % ! . -"
echo "    Arabic Letters:    blocked (unicode blocks)"
echo ""
echo "  PASS=${PASS}  FAIL=${FAIL}  WARN=${WARN}"
echo "============================================================"

if [[ "$FAIL" -gt 0 ]]; then
  echo "Result: FAIL — ${FAIL} checks failed"
  exit 1
elif [[ "$WARN" -gt 0 ]]; then
  echo "Result: PASS with ${WARN} warning(s)"
  exit 0
else
  echo "Result: ALL PASS"
  exit 0
fi
