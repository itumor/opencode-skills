# bank-add-orclisenabled.sh — Runbook

Adds the `orclisenabled` custom attribute (OID 1.3.6.1.4.1.55555.1.16) to the
`bank-custom` schema on Symas OpenLDAP 2.6.13.

## Quick Start

```bash
# Run on BOTH master and replica (master first)
sudo bash bank-add-orclisenabled.sh --force
```

## What it does

1. Locates the `bank-custom` schema in `cn=config`
2. Adds `olcAttributeTypes: orclisenabled` (booleanMatch syntax)
3. Adds `orclisenabled` to `bankUserExtension` MAY list
4. Creates a timestamped backup before any change
5. Functional test: creates, reads, and deletes a test entry
6. Idempotent — safe to run again, skips if already present

## Commands

| Command | Purpose |
|---------|---------|
| `sudo bash bank-add-orclisenabled.sh --force` | Apply changes (no prompts) |
| `sudo bash bank-add-orclisenabled.sh --dry-run` | Preview only, no changes |
| `sudo bash bank-add-orclisenabled.sh --restore <file>` | Rollback from backup |
| `sudo bash bank-add-orclisenabled.sh --help` | Show all options |

## Backups

Stored in `/var/symas/openldap-data/backup/bank-custom-<timestamp>.ldif`

Rollback: `sudo bash bank-add-orclisenabled.sh --restore /var/symas/openldap-data/backup/bank-custom-YYYYMMDD-HHMMSS.ldif`

## Requirements

- Root access
- `bank-custom` schema must exist (run `12-Create_custom_schema.sh` first)
- slapd must be running
- LDAPI (`ldapi:///`) must be accessible

## Verification

After running, the script verifies:
- `orclisenabled` attribute exists in schema
- `orclisenabled` is in `bankUserExtension` MAY list
- Functional test: creates/reads/deletes a test LDAP entry

On replicas: the functional test detects read-only mode and reports a warning
(schema is still verified OK — referral to master is expected).

## Troubleshooting

### "Schema bank-custom not found"
Run `12-Create_custom_schema.sh` first, then retry.

### "Failed to create test entry"
Check admin password with `ADMIN_PW=YourPassword sudo bash bank-add-orclisenabled.sh --force`.
Default admin password: `TheN1le1`.

### "Another instance is already running"
Wait or remove the lock: `rm -f /tmp/bank-add-orclisenabled.lock`
